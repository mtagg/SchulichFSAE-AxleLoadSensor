/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "nRF24L01.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SDADC_HandleTypeDef hsdadc2;

SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
uint8_t addressA[6] = "SR21A";
uint8_t addressB[6] = "SR21B";
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SDADC2_Init(void);
/* USER CODE BEGIN PFP */
void writeCE(int set);
void writeCSn(int set);
void writeReg(uint8_t reg, uint8_t set);
void readReg(uint8_t* buff, uint8_t reg, uint8_t byteLength);
void flushRX();
void flushTX();
void readRadio(uint8_t* data, int bytes);
void writeRadio(uint16_t data);
void Tx_Init();
void TESTCODE();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_SDADC2_Init();
  /* USER CODE BEGIN 2 */
  Tx_Init();
  TESTCODE();
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, 1); // green LED set - on indicator
  uint16_t ADC_DATA = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  HAL_SDADC_Start(&hsdadc2);
	  HAL_SDADC_PollForConversion(&hsdadc2, HAL_MAX_DELAY);
	  ADC_DATA = (uint16_t)HAL_SDADC_GetValue(&hsdadc2);
	  HAL_SDADC_Stop(&hsdadc2);
	  writeRadio(ADC_DATA);
	  HAL_Delay(25);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  HAL_SDADC_DeInit(&hsdadc2);
  return 1;
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_SDADC;
  PeriphClkInit.SdadcClockSelection = RCC_SDADCSYSCLK_DIV2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_PWREx_EnableSDADC(PWR_SDADC_ANALOG2);
}

/**
  * @brief SDADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDADC2_Init(void)
{

  /* USER CODE BEGIN SDADC2_Init 0 */

  /* USER CODE END SDADC2_Init 0 */

  SDADC_ConfParamTypeDef ConfParamStruct = {0};

  /* USER CODE BEGIN SDADC2_Init 1 */

  /* USER CODE END SDADC2_Init 1 */
  /** Configure the SDADC low power mode, fast conversion mode,
  slow clock mode and SDADC1 reference voltage
  */
  hsdadc2.Instance = SDADC2;
  hsdadc2.Init.IdleLowPowerMode = SDADC_LOWPOWER_NONE;
  hsdadc2.Init.FastConversionMode = SDADC_FAST_CONV_DISABLE;
  hsdadc2.Init.SlowClockMode = SDADC_SLOW_CLOCK_DISABLE;
  hsdadc2.Init.ReferenceVoltage = SDADC_VREF_EXT;
  if (HAL_SDADC_Init(&hsdadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure The Regular Mode
  */
  if (HAL_SDADC_SelectRegularTrigger(&hsdadc2, SDADC_SOFTWARE_TRIGGER) != HAL_OK)
  {
    Error_Handler();
  }
  /** Set parameters for SDADC configuration 0 Register
  */
  ConfParamStruct.InputMode = SDADC_INPUT_MODE_DIFF;
  ConfParamStruct.Gain = SDADC_GAIN_1;
  ConfParamStruct.CommonMode = SDADC_COMMON_MODE_VSSA;
  ConfParamStruct.Offset = 0;
  if (HAL_SDADC_PrepareChannelConfig(&hsdadc2, SDADC_CONF_INDEX_0, &ConfParamStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the Regular Channel
  */
  if (HAL_SDADC_AssociateChannelConfig(&hsdadc2, SDADC_CHANNEL_8, SDADC_CONF_INDEX_0) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_SDADC_ConfigChannel(&hsdadc2, SDADC_CHANNEL_8, SDADC_CONTINUOUS_CONV_OFF) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SDADC2_Init 2 */

  /* USER CODE END SDADC2_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2|GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA2 PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void writeCE(int set){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, set);
}
void writeCSn(int set){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, set);
}
void writeReg(uint8_t reg, uint8_t set){
	//Using SPI1

	uint8_t MESSAGE[2] = {W_REGISTER | reg, set};
	writeCSn(0);// start SPI message
    HAL_SPI_Transmit(&hspi1, &MESSAGE[0], 2, 10); //access register[0] and send setting[1]
    writeCSn(1);//stop SPI message

}
void readReg(uint8_t* buff, uint8_t reg, uint8_t byteLength){
	//using SPI1
	uint8_t status;
	buff[0] = (R_REGISTER | reg);
	writeCSn(GPIO_PIN_RESET);// start SPI message
    HAL_SPI_TransmitReceive(&hspi1, buff, &status, 1, 10); //access register and save status bit
    HAL_SPI_Receive(&hspi1, buff, byteLength, 10);		   //read register settings
    writeCSn(GPIO_PIN_SET);//stop SPI message

    return;
}
void flushRX(){
	// FLUSH_TX & FLUSH RX FIFO BUFFERS:
		   uint8_t message[1] = {FLUSH_RX};
		   writeCSn(0);
		   HAL_SPI_Transmit(&hspi1, &message[0], 1, 10);
		   writeCSn(1);
		   HAL_Delay(1);
}
void flushTX(){
	// FLUSH_RX FIFO BUFFER
			uint8_t message[1] = {FLUSH_TX};
			writeCSn(0);
			HAL_SPI_Transmit(&hspi1, &message[0], 1, 10);
			writeCSn(1);
			HAL_Delay(1);

}
void readRadio(uint8_t* data, int bytes){
	uint8_t Status[4] = {0x00,0x00,0x00,0x00};
	readReg(&Status[0],NRF_STATUS,1);
	uint8_t Rx_Available = Status[0] >> 6; //LSB is now RX_DR
	uint8_t Pipe = (Status[0] >> 1) & 0x07; //LSBits are now Pipe number for payload
	if(Rx_Available > 0){//RX_DR is set high
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
		//check pipe:
		if(Pipe == 0){//package from pipe A
			//read payload and assign to (uint16_t A_Data)
			data[0] = 1;
			data[1] = 2;
		}else if (Pipe == 1){//package from pipe B
			//read payload and assign to (uint16_t B_Data)
			data[2] = 3;
			data[3] = 4;
		}
		//UART TESTING
		writeReg(NRF_STATUS , 0b01110000); //reset status interrupt bits
	}
	return;
}
void writeRadio(uint16_t data){
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 1);
	//clear tx/rx buffer
	flushTX();
	flushRX();
	//power on device
	uint8_t buff[1];
//	readReg(&buff[0], FIFO_STATUS, 1);
	readReg(&buff[0], NRF_CONFIG, 1);
	writeReg(NRF_CONFIG, 0xfe & buff[0]);
	//build packet
	uint8_t message[3];
	message[0] = W_TX_PAYLOAD;
	message[1] = data & 0x00ff;
	message[2] = (data & 0xff00) >> 8;
	//send packet

	writeCSn(0);
	HAL_SPI_Transmit(&hspi1, &message[0], 3, 100);
	writeCSn(1);

	//buffer time & close SPI message
	writeCE(1);
	HAL_Delay(1);
	writeCE(0);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 0);
	return;
}
void Tx_Init(){
	// payload size:2
	// PA level : low, -18dBa
	// Pipe count : 2 (addressA and addressB)
	// CRC : on, 2 bits
		writeCE(0); //disable RF stuff for setup
		writeCSn(1);
		HAL_Delay(1);     // 1 ms delay
// SET AUTO RETRANSMISSION
	    writeReg(SETUP_RETR, 0b00000000);//retransmit disabled, all bout that real-time data, yo!
// SET RF CHANNEL (set for 120 out of 125 - local wifi typically uses the lower channels, avoid if possible
	    writeReg(RF_CH, 120);//set channel for nRF24L01
// SET RF_SETUP
	    writeReg(RF_SETUP, 0b00000001); // PA level == '00' (low -18dBM) LNA
// SET STATUS
	    writeReg(NRF_STATUS , 0b01110000); //reset status interrupt bits
// SET SETUP_AW
	    writeReg(SETUP_AW, 0b00000011); //receive address size - 5 bytes
// Set Tx Address:
	//Left axle (A)
	    uint8_t message[1] = {TX_ADDR | W_REGISTER};
	    writeCSn(0);
	    HAL_SPI_Transmit(&hspi1, &message[0], 1, 10);
	    HAL_SPI_Transmit(&hspi1, addressA, 5, 10);
	    writeCSn(1);
	    HAL_Delay(1);
	//RX_ADDR_P0 (same address as Tx address for PTX with enhanced shockburst(nRF24L01)
	    writeReg(EN_RXADDR, 0b11);
	    message[0] = W_REGISTER | RX_ADDR_P0;
	    writeCSn(0);
	    HAL_SPI_Transmit(&hspi1, &message[0], 1, 10);
	    HAL_SPI_Transmit(&hspi1, addressA, 5, 10);
	    writeCSn(1);
	    HAL_Delay(1);

//enable ACK on all pipes;
		writeReg(EN_AA,0b00111111);
// FLUSH_TX & FLUSH RX FIFO BUFFERS:
	    flushTX();
// FLUSH_RX FIFO BUFFER
	    flushRX();
// SET CONFIG REGISTER
	   	writeReg(NRF_CONFIG, 0b01111110); // Rx mode - no IRQ - CRC enabled (set LSB to 0 if tx mode) 0b01111111 for RX
//finished initialization
	    HAL_Delay(1);
	    return;
}

void TESTCODE(){
	  //TEST CODE//
	  uint8_t BUFFER[5] = {0}; //up to 4 bytes, max package size is 2 - should be safe :D
	  readReg(&BUFFER[0], NRF_CONFIG, 1);
	  readReg(&BUFFER[0], SETUP_RETR, 1);
	  readReg(&BUFFER[0], RF_CH, 1);
	  readReg(&BUFFER[0], NRF_STATUS, 1);
	  readReg(&BUFFER[0], SETUP_AW, 1);
	  readReg(&BUFFER[0], TX_ADDR, 5);
	  readReg(&BUFFER[0], EN_AA, 1);
	  //END TEST CODE//
	  return;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
